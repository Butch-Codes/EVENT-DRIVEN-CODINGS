﻿using PreFinalApp.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PreFinalApp
{
    public partial class frmMaster : Form
    {
        string conString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\COMLAB507\\Downloads\\PreFinalApp\\PreFinalApp\\PreFinalApp\\Database1.mdf;Integrated Security=True";
        public int SelectedID = 0;
        public frmMaster()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {            
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            LoadGrid();
        }

        private void LoadGrid()
        {
            using (var db = new MyDbContextV2(conString))
            {
                //all columns
                //dataGridView2.DataSource = db.Students.ToList();

                //selected coluns
                dataGridView2.DataSource = db.Students.Select(r => new StudentGrid
                {
                    Id = r.Id,
                    LastName = r.LastName,
                    FirstName = r.FirstName,
                    EmailAddress = r.EmailAddress,
                    StudentId = r.StudentId
                }).ToList();
                dataGridView2.ClearSelection();
            }
        }

        private void dataGridView2_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView2.Rows[e.RowIndex];
                int cellValue = (int) selectedRow.Cells["ID"].Value;
                frmFileManagement singleData = new frmFileManagement();
                singleData.SelectedID = cellValue;
                singleData.ShowDialog();
                LoadGrid();
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {     
            Console.WriteLine($"Selected ID: {SelectedID}");
            string conString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\COMLAB507\\source\\repos\\PreFinalApp\\Database1.mdf;Integrated Security=True";

            using (var db = new MyDbContextV2(conString))
            {
                var selRow = (from row in db.Students where row.Id == SelectedID select row).FirstOrDefault();
                if (selRow != null)
                {
                    db.Students.Remove(selRow);
                    db.SaveChanges();
                    LoadGrid();
                    MessageBox.Show("Record has been deleted");
                }
                          
            }
           
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView2.Rows[e.RowIndex];
                int cellValue = (int)selectedRow.Cells["ID"].Value;
                SelectedID = cellValue;
            }
        }

        private void btnNewRecord_Click(object sender, EventArgs e)
        {
            frmDetail singleData = new frmDetail();
            singleData.SelectedID = -1;
            singleData.ShowDialog();
            LoadGrid();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            frmDetail singleData = new frmDetail();
            singleData.SelectedID = SelectedID;
            singleData.ShowDialog();
            LoadGrid();
        }
    }
}
